package com.elmosakes.whatsappreport

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 3, 7)
    private val white = Color.rgb(250, 241, 246)
    private val muted = Color.rgb(194, 164, 180)
    private val red = Color.rgb(255, 30, 58)
    private val burgundy = Color.rgb(139, 25, 69)
    private lateinit var prefs: SharedPreferences
    private var isUnlocked = false
    private var shouldRelock = false
    private val reasonOptions = listOf("محتوى غير لائق", "إزعاج متكرر", "انتحال شخصية", "احتيال", "تهديد أو عنف", "أسباب أخرى")
    private val selectedReasons = linkedSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("mosakes_settings", MODE_PRIVATE)
        if (!prefs.contains("password")) prefs.edit().putString("password", "HAMO11").apply()
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        showLockScreen()
    }

    override fun onStop() {
        if (isUnlocked) { isUnlocked = false; shouldRelock = true }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (shouldRelock) { shouldRelock = false; showLockScreen() }
    }

    private fun showLockScreen() {
        val root = baseRoot(24, 30, 24, 30)
        val spacer = View(this)
        root.addView(spacer, lp(1, 0, 1f))
        root.addView(label("حظر أرقام برعايه", 27, true, white, Gravity.CENTER).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); minHeight = dp(64) }, lp(-1, -2))
        root.addView(label("✦ أدخل كلمة السر للمتابعة ✦", 16, false, red, Gravity.CENTER).apply { setPadding(dp(8), dp(6), dp(8), dp(10)) }, lp(-1, -2).apply { bottomMargin = dp(14) })
        val password = edit("كلمة السر", true)
        root.addView(password, lp(-1, 78).apply { topMargin = dp(8); bottomMargin = dp(8) })
        val error = label("كلمة السر غير صحيحة", 14, false, red, Gravity.CENTER).apply { visibility = View.GONE }
        root.addView(actionButton("دخول 🔓", 17), lp(-1, 82).apply { topMargin = dp(12) })
        val unlock = (root.getChildAt(root.childCount - 1) as TextView)
        root.addView(error, lp(-1, -2).apply { bottomMargin = dp(4) })
        root.addView(View(this), lp(1, 0, 1f))
        unlock.setOnClickListener {
            if (password.text.toString() == prefs.getString("password", "HAMO11")) {
                isUnlocked = true; shouldRelock = false; showDashboard()
            } else { error.visibility = View.VISIBLE; password.text.clear() }
        }
        password.setOnEditorActionListener { _, _, _ -> unlock.performClick(); true }
        setContentView(root)
    }

    private fun showDashboard() {
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setBackgroundColor(Color.BLACK) }
        val root = baseRoot(18, 24, 18, 36)
        scroll.addView(root)
        val header = card()
        header.addView(label("حظر أرقام برعايه", 26, true, white, Gravity.CENTER).apply { setPadding(0, dp(8), 0, dp(8)) }, lp(-1, -2))
        header.addView(label("✨ €ℰℒ _𝓂ℴ𝓈𝒶𝓀𝓮𝓼_ℋ_𝒜_ℳ_ℴ_¥❌", 13, true, Color.rgb(255, 98, 139), Gravity.CENTER), lp(-1, -2))
        header.addView(label("الإصدار 2.6  •  لوحة التحكم الشيطانية", 12, false, muted, Gravity.CENTER).apply { setPadding(0, dp(5), 0, dp(8)) }, lp(-1, -2))
        root.addView(header, lp(-1, -2).apply { bottomMargin = dp(18) })

        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val navItems = listOf("✦ بلاغ جديد" to { showReportForm() }, "▤ السجل" to { showHistory() }, "◈ الإحصائيات" to { showStats() }, "⚙ الإعدادات" to { showSettings() })
        navItems.chunked(2).forEach { group ->
            val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            group.forEach { (title, click) ->
                val b = actionButton(title, 14).apply { setOnClickListener { click() }; minHeight = dp(58) }
                navRow.addView(b, LinearLayout.LayoutParams(0, dp(84), 1f).apply { leftMargin = dp(7); rightMargin = dp(7); bottomMargin = dp(12) })
            }
            nav.addView(navRow, lp(-1, -2))
        }
        root.addView(nav, lp(-1, -2).apply { bottomMargin = dp(12) })
        val intro = card()
        intro.addView(label("أهلًا بك في المقرّ", 22, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(8) })
        intro.addView(label("أنشئ مسودة بلاغ، احفظها على جهازك، وراجع سجلّك في أي وقت.", 14, false, muted, Gravity.RIGHT), lp(-1, -2))
        root.addView(intro, lp(-1, -2).apply { bottomMargin = dp(18) })

        val stats = card()
        val reports = getReports()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf("إجمالي المسودات" to reports.length().toString(), "هذا الشهر" to countThisMonth(reports).toString(), "أسباب شائعة" to mostCommonReason(reports)).forEach { (title, value) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8)) }
            item.addView(label(value, if (value.length > 6) 13 else 22, true, Color.rgb(255, 65, 92), Gravity.CENTER), lp(-1, -2).apply { bottomMargin = dp(4) })
            item.addView(label(title, 11, false, muted, Gravity.CENTER), lp(-1, -2))
            row.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        stats.addView(row, lp(-1, -2))
        root.addView(stats, lp(-1, -2).apply { bottomMargin = dp(18) })
        val quick = actionButton("＋ إنشاء بلاغ جديد", 18).apply { setOnClickListener { showReportForm() } }
        root.addView(quick, lp(-1, 82))
        root.addView(label("✦  EL MOSAKES  ✦", 12, false, Color.rgb(255, 40, 75), Gravity.CENTER), lp(-1, 40).apply { topMargin = dp(8) })
        setContentView(scroll)
    }

    private fun showReportForm() {
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Color.BLACK) }
        val root = baseRoot(18, 24, 18, 36)
        scroll.addView(root)
        pageHeader(root, "إنشاء بلاغ جديد", "المعلومات تُحفظ محليًا كمسودة قبل فتح البريد")
        val phoneCard = card()
        phoneCard.addView(label("رقم الهاتف أو واتساب", 17, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(8) })
        val phone = edit("+20 10 1234 5678", false).apply { inputType = InputType.TYPE_CLASS_PHONE }
        phoneCard.addView(phone, lp(-1, 82))
        root.addView(phoneCard, lp(-1, -2).apply { bottomMargin = dp(20) })
        val reasonCard = card()
        reasonCard.addView(label("سبب الإبلاغ والتفاصيل", 17, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(8) })
        val details = edit("اكتب سبب البلاغ والتفاصيل هنا...", false).apply {
            minLines = 4; gravity = Gravity.TOP or Gravity.RIGHT
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        reasonCard.addView(details, lp(-1, 132))
        reasonCard.addView(label("اختر سبب الإبلاغ (اختياري)", 14, false, muted, Gravity.RIGHT).apply { setPadding(0, dp(12), 0, dp(6)) }, lp(-1, -2))
        selectedReasons.clear()
        reasonOptions.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            pair.forEach { reason ->
                val chip = actionButton(reason, 12)
                chip.setOnClickListener {
                    if (selectedReasons.remove(reason)) chip.background = rounded(Color.rgb(16, 4, 9), red, 22)
                    else { selectedReasons.add(reason); chip.background = rounded(Color.rgb(112, 5, 28), Color.rgb(255, 100, 120), 22) }
                }
                row.addView(chip, LinearLayout.LayoutParams(0, dp(84), 1f).apply { leftMargin = dp(7); rightMargin = dp(7); bottomMargin = dp(14) })
            }
            reasonCard.addView(row, lp(-1, -2))
        }
        root.addView(reasonCard, lp(-1, -2).apply { bottomMargin = dp(18) })
        val save = actionButton("حفظ المسودة", 17).apply { setOnClickListener {
            val number = phone.text.toString().trim()
            val typed = details.text.toString().trim()
            val reasons = selectedReasons.joinToString("، ")
            if (number.count { it.isDigit() } < 7) { toast("اكتب رقم هاتف صحيحًا"); return@setOnClickListener }
            if (typed.isBlank() && reasons.isBlank()) { toast("اكتب التفاصيل أو اختر سببًا"); return@setOnClickListener }
            saveReport(number, typed, reasons, "مسودة محفوظة")
            toast("تم حفظ المسودة على الجهاز")
            showDashboard()
        } }
        root.addView(save, lp(-1, 82).apply { bottomMargin = dp(12) })
        val send = actionButton("😈 ارفعو علي بتاعي ➤", 21).apply { setOnClickListener {
            val number = phone.text.toString().trim()
            val typed = details.text.toString().trim()
            val reasons = selectedReasons.joinToString("، ")
            if (number.count { it.isDigit() } < 7) { toast("اكتب رقم هاتف صحيحًا"); return@setOnClickListener }
            if (typed.isBlank() && reasons.isBlank()) { toast("اكتب التفاصيل أو اختر سببًا"); return@setOnClickListener }
            val allDetails = listOf(typed, if (reasons.isNotBlank()) "أسباب مختارة: $reasons" else "").filter { it.isNotBlank() }.joinToString("\n")
            saveReport(number, typed, reasons, "تم فتح البريد")
            val mail = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@whatsapp.com")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("support@whatsapp.com"))
                putExtra(Intent.EXTRA_SUBJECT, "طلب مراجعة بلاغ عن رقم واتساب")
                putExtra(Intent.EXTRA_TEXT, "أرغب في مراجعة الرقم التالي وفقًا لسياسات الخدمة:\nالرقم: $number\nسبب البلاغ: $allDetails\n\nيرجى التحقق من المعلومات قبل اتخاذ أي إجراء.")
            }
            try { startActivity(Intent.createChooser(mail, "اختر تطبيق البريد لإرسال المسودة")) }
            catch (_: Exception) { toast("لا يوجد تطبيق بريد متاح؛ تم حفظ المسودة") }
        } }
        root.addView(send, lp(-1, 82))
        root.addView(actionButton("رجوع للوحة التحكم", 15).apply { setOnClickListener { showDashboard() } }, lp(-1, 78).apply { topMargin = dp(16) })
        setContentView(scroll)
    }

    private fun showHistory() {
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(Color.BLACK) }
        val root = baseRoot(18, 24, 18, 36); scroll.addView(root)
        pageHeader(root, "سجل البلاغات", "محفوظ على هذا الجهاز فقط")
        val reports = getReports()
        if (reports.length() == 0) root.addView(label("لا توجد مسودات محفوظة حتى الآن.", 16, false, muted, Gravity.CENTER), lp(-1, 90))
        for (i in reports.length() - 1 downTo 0) {
            val item = reports.getJSONObject(i)
            val c = card()
            c.addView(label(item.optString("number"), 18, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(6) })
            c.addView(label(item.optString("date"), 12, false, muted, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(4) })
            c.addView(label("الحالة: ${item.optString("status")}", 12, false, Color.rgb(255, 90, 120), Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(4) })
            c.addView(label("الأسباب: ${item.optString("reasons", "—")}", 13, false, muted, Gravity.RIGHT), lp(-1, -2))
            c.addView(label("${item.optString("details")}", 14, false, white, Gravity.RIGHT), lp(-1, -2))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            actions.addView(actionButton("إعادة فتح البريد", 12).apply { setOnClickListener {
                val mail = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:support@whatsapp.com")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("support@whatsapp.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "طلب مراجعة بلاغ عن رقم واتساب")
                    putExtra(Intent.EXTRA_TEXT, "الرقم: ${item.optString("number")}\nالتفاصيل: ${item.optString("details")}\nالأسباب: ${item.optString("reasons")}")
                }
                try { startActivity(Intent.createChooser(mail, "اختر تطبيق البريد")) } catch (_: Exception) { toast("لا يوجد تطبيق بريد") }
            } }, LinearLayout.LayoutParams(0, dp(78), 1f).apply { rightMargin = dp(5) })
            actions.addView(actionButton("حذف", 12).apply { setOnClickListener { deleteReport(item.optString("id")); showHistory() } }, LinearLayout.LayoutParams(0, dp(78), 1f).apply { leftMargin = dp(5) })
            c.addView(actions, lp(-1, -2).apply { topMargin = dp(8) })
            root.addView(c, lp(-1, -2).apply { bottomMargin = dp(16) })
        }
        if (reports.length() > 0) root.addView(actionButton("مسح كل السجل", 14).apply { setOnClickListener { prefs.edit().putString("reports", "[]").apply(); toast("تم مسح السجل"); showHistory() } }, lp(-1, 78))
        root.addView(actionButton("رجوع للوحة التحكم", 14).apply { setOnClickListener { showDashboard() } }, lp(-1, 78).apply { topMargin = dp(8) })
        setContentView(scroll)
    }

    private fun showStats() {
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setBackgroundColor(Color.BLACK) }
        val root = baseRoot(18, 24, 18, 36)
        scroll.addView(root)
        pageHeader(root, "الإحصائيات", "أرقام محلية من سجل جهازك")
        val reports = getReports()
        val allReasons = mutableListOf<String>()
        for (i in 0 until reports.length()) allReasons.addAll(reports.getJSONObject(i).optString("reasons").split("،").map { it.trim() }.filter { it.isNotBlank() })
        val counts = allReasons.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
        val c = card()
        c.addView(label("إجمالي المسودات: ${reports.length()}", 21, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(8) })
        c.addView(label("هذا الشهر: ${countThisMonth(reports)}", 17, true, Color.rgb(255, 75, 100), Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(4) })
        c.addView(label("عدد الأسباب المختارة: ${allReasons.size}", 15, false, muted, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(6) })
        c.addView(label("أكثر الأسباب استخدامًا", 17, true, white, Gravity.RIGHT).apply { setPadding(0, dp(12), 0, dp(6)) }, lp(-1, -2))
        if (counts.isEmpty()) c.addView(label("لا توجد بيانات كافية بعد.", 14, false, muted, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(6) })
        counts.take(6).forEach { c.addView(label("${it.key}: ${it.value}", 14, false, muted, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(5) }) }
        root.addView(c, lp(-1, -2).apply { bottomMargin = dp(18) })
        root.addView(actionButton("رجوع للوحة التحكم", 15).apply { setOnClickListener { showDashboard() } }, lp(-1, 78))
        setContentView(scroll)
    }

    private fun showSettings() {
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setBackgroundColor(Color.BLACK) }
        val root = baseRoot(18, 24, 18, 36)
        scroll.addView(root)
        pageHeader(root, "الإعدادات والحماية", "التغييرات تُحفظ محليًا")
        val c = card()
        c.addView(label("تغيير كلمة السر", 20, true, white, Gravity.RIGHT).apply { setPadding(0, dp(4), 0, dp(8)) }, lp(-1, -2))
        val current = edit("كلمة السر الحالية", true); c.addView(current, lp(-1, 78).apply { bottomMargin = dp(16) })
        val newPass = edit("كلمة السر الجديدة (4 أحرف على الأقل)", true); c.addView(newPass, lp(-1, 78).apply { bottomMargin = dp(16) })
        val confirm = edit("تأكيد كلمة السر الجديدة", true); c.addView(confirm, lp(-1, 78).apply { bottomMargin = dp(18) })
        c.addView(actionButton("حفظ كلمة السر الجديدة", 15).apply { setOnClickListener {
            val old = prefs.getString("password", "HAMO11") ?: "HAMO11"
            if (current.text.toString() != old) { toast("كلمة السر الحالية غير صحيحة"); return@setOnClickListener }
            if (newPass.text.length < 4) { toast("كلمة السر الجديدة قصيرة جدًا"); return@setOnClickListener }
            if (newPass.text.toString() != confirm.text.toString()) { toast("تأكيد كلمة السر غير مطابق"); return@setOnClickListener }
            prefs.edit().putString("password", newPass.text.toString()).apply()
            toast("تم تغيير كلمة السر"); showDashboard()
        } }, lp(-1, 78))
        root.addView(c, lp(-1, -2).apply { bottomMargin = dp(18) })
        val note = card()
        note.addView(label("الخصوصية", 18, true, white, Gravity.RIGHT), lp(-1, -2).apply { bottomMargin = dp(6) })
        note.addView(label("سجل البلاغات وكلمة السر محفوظان محليًا على هذا الجهاز. حذف التطبيق أو بياناته قد يمسح السجل. لا تشارك كلمة السر مع الآخرين.", 13, false, muted, Gravity.RIGHT), lp(-1, -2))
        root.addView(note, lp(-1, -2).apply { bottomMargin = dp(18) })
        root.addView(actionButton("رجوع للوحة التحكم", 15).apply { setOnClickListener { showDashboard() } }, lp(-1, 78))
        setContentView(scroll)
    }

    private fun saveReport(number: String, details: String, reasons: String, status: String) {
        val reports = getReports()
        reports.put(JSONObject().apply {
            put("id", System.currentTimeMillis().toString())
            put("number", number); put("details", details); put("reasons", reasons)
            put("status", status)
            put("date", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
            put("month", SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date()))
        })
        prefs.edit().putString("reports", reports.toString()).apply()
    }

    private fun getReports(): JSONArray = try { JSONArray(prefs.getString("reports", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun deleteReport(id: String) {
        val old = getReports(); val next = JSONArray()
        for (i in 0 until old.length()) if (old.getJSONObject(i).optString("id") != id) next.put(old.getJSONObject(i))
        prefs.edit().putString("reports", next.toString()).apply()
    }
    private fun countThisMonth(a: JSONArray): Int {
        val month = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())
        var n = 0; for (i in 0 until a.length()) if (a.getJSONObject(i).optString("month") == month) n++
        return n
    }
    private fun mostCommonReason(a: JSONArray): String {
        val values = mutableListOf<String>(); for (i in 0 until a.length()) values.addAll(a.getJSONObject(i).optString("reasons").split("،").map { it.trim() }.filter { it.isNotBlank() })
        return values.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: "—"
    }

    private fun pageHeader(root: LinearLayout, title: String, subtitle: String) {
        val heading = label(title, 25, true, white, Gravity.CENTER).apply {
            setPadding(dp(10), dp(14), dp(10), dp(14))
            minHeight = dp(64)
        }
        root.addView(heading, lp(-1, -2))
        val subheading = label(subtitle, 14, false, muted, Gravity.CENTER).apply {
            setPadding(dp(10), dp(8), dp(10), dp(16))
            minHeight = dp(50)
        }
        root.addView(subheading, lp(-1, -2).apply { bottomMargin = dp(12) })
    }
    private fun baseRoot(left: Int, top: Int, right: Int, bottom: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        setPadding(dp(left), dp(top), dp(right), dp(bottom))
        setBackgroundResource(R.drawable.demon_background_overlay)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(28), dp(22), dp(28))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(226, 10, 2, 6), Color.argb(236, 25, 4, 12))).apply {
            cornerRadius = dp(22).toFloat(); setStroke(dp(1), red)
        }
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
    private fun label(textValue: String, size: Int, bold: Boolean, color: Int, gravityValue: Int) = TextView(this).apply {
        text = textValue; textSize = size.toFloat(); setTextColor(color); gravity = gravityValue
        includeFontPadding = true
        setLineSpacing(dp(6).toFloat(), 1.12f)
        maxLines = 10
        ellipsize = null
        setPadding(paddingLeft, dp(3), paddingRight, dp(3))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun edit(hintValue: String, secret: Boolean) = EditText(this).apply {
        hint = hintValue; textSize = 16f; setSingleLine(secret); setTextColor(white); setHintTextColor(Color.rgb(150, 125, 145))
        if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        setPadding(dp(18), dp(20), dp(18), dp(20))
        minHeight = dp(64)
        gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        background = rounded(Color.rgb(25, 15, 24), Color.rgb(125, 75, 100), 14)
    }
    private fun actionButton(textValue: String, size: Int = 15) = TextView(this).apply {
        // TextView is used instead of the platform Button to avoid OEM-specific insets
        // that were clipping Arabic labels on some devices.
        text = textValue
        textSize = size.toFloat()
        setTextColor(white)
        isClickable = true
        isFocusable = true
        gravity = Gravity.CENTER
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        includeFontPadding = true
        setLineSpacing(dp(4).toFloat(), 1.12f)
        maxLines = 3
        ellipsize = null
        minHeight = dp(76)
        minimumHeight = dp(76)
        minimumWidth = dp(76)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(20, 2, 7), burgundy, Color.rgb(20, 2, 7))).apply {
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), red)
        }
    }
    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun lp(width: Int, height: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        if (weight > 0f) LinearLayout.LayoutParams(width, height, weight) else LinearLayout.LayoutParams(width, height)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
