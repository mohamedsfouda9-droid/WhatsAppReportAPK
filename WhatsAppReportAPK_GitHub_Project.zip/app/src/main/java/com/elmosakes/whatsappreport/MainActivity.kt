package com.elmosakes.whatsappreport

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 8, 13)
    private val white = Color.rgb(248, 239, 244)
    private val muted = Color.rgb(195, 171, 184)
    private val burgundy = Color.rgb(142, 36, 77)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
            setBackgroundResource(com.elmosakes.whatsappreport.R.drawable.demon_background_overlay)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)
        setContentView(scroll)

        val logo = TextView(this).apply {
            text = "✦"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(230, 91, 139))
        }
        root.addView(logo, lp(-1, dp(48)))

        val title = TextView(this).apply {
            text = "حظر أرقام برعايه"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
        }
        root.addView(title, lp(-1, dp(44)))

        val username = TextView(this).apply {
            text = "✨€ℰℒ _𝓂ℴ𝓈𝒶𝓀ℯ𝓈_ℋ_𝒜_ℳ_ℴ_¥❌"
            textSize = 16f
            gravity = Gravity.CENTER
            typeface = Typeface.create("serif", Typeface.BOLD_ITALIC)
            setTextColor(Color.rgb(255, 104, 142))
        }
        root.addView(username, lp(-1, dp(40)))

        val subtitle = TextView(this).apply {
            text = "بلاغات واتساب • تصميم ملك الشياطين"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }
        root.addView(subtitle, lp(-1, dp(36)))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(Color.rgb(31, 19, 27), Color.rgb(101, 48, 70), 22)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val panelParams = lp(-1, -2).apply { topMargin = dp(20) }
        root.addView(panel, panelParams)

        addLabel(panel, "رقم الهاتف أو واتساب")
        val phone = EditText(this).apply {
            hint = "مثال: +20xxxxxxxxxx"
            textSize = 16f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(Color.rgb(145, 120, 134))
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(36, 27, 34), Color.rgb(96, 64, 82), 13)
        }
        panel.addView(phone, lp(-1, dp(52)))

        addLabel(panel, "سبب البلاغ")
        val reason = EditText(this).apply {
            hint = "اكتب سبب البلاغ بوضوح..."
            textSize = 15f
            minLines = 4
            gravity = Gravity.TOP or Gravity.RIGHT
            setTextColor(white)
            setHintTextColor(Color.rgb(145, 120, 134))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(36, 27, 34), Color.rgb(96, 64, 82), 13)
        }
        val reasonParams = lp(-1, dp(120)).apply { topMargin = dp(8) }
        panel.addView(reason, reasonParams)

        val send = Button(this).apply {
            text = "ارفعو علي بتاعي 😈"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(burgundy, Color.rgb(190, 68, 111), 16)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val sendParams = lp(-1, dp(54)).apply { topMargin = dp(20) }
        panel.addView(send, sendParams)

        send.setOnClickListener {
            val number = phone.text.toString().trim()
            val details = reason.text.toString().trim()
            if (number.isBlank() || details.isBlank()) {
                Toast.makeText(this, "اكتب الرقم وسبب البلاغ أولًا", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val body = "أرغب في مراجعة الرقم التالي وفقًا لسياسات الخدمة:\\nالرقم: $number\\nسبب البلاغ: $details\\n\\nيرجى مراجعة البلاغ والتحقق منه. أرسل هذا البلاغ فقط إذا كانت المعلومات صحيحة."
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@whatsapp.com")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("support@whatsapp.com"))
                putExtra(Intent.EXTRA_SUBJECT, "طلب مراجعة بلاغ عن رقم واتساب")
                putExtra(Intent.EXTRA_TEXT, body)
            }
            try {
                startActivity(Intent.createChooser(intent, "اختر تطبيق البريد لمراجعة الرسالة"))
            } catch (_: Exception) {
                Toast.makeText(this, "لا يوجد تطبيق بريد متاح على الجهاز", Toast.LENGTH_LONG).show()
            }
        }

        val footer = TextView(this).apply {
            text = "✦  EL MOSAKES  ✦"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(176, 74, 111))
            letterSpacing = 0.12f
        }
        val footerParams = lp(-1, dp(36)).apply { topMargin = dp(8) }
        root.addView(footer, footerParams)
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(16), 0, dp(8))
        }
        parent.addView(label, lp(-1, -2))
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun lp(width: Int, height: Int) =
        LinearLayout.LayoutParams(width, height)

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
