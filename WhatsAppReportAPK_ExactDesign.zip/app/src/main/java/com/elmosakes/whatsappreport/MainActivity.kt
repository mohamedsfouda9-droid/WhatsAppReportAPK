package com.elmosakes.whatsappreport

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 8, 13)
    private val white = Color.rgb(248, 239, 244)
    private val muted = Color.rgb(195, 171, 184)
    private val burgundy = Color.rgb(142, 36, 77)
    private val appPassword = "HAMO11"
    private var isUnlocked = false
    private var shouldRelock = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        showLockScreen()
    }

    override fun onStop() {
        if (isUnlocked) {
            isUnlocked = false
            shouldRelock = true
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (shouldRelock) {
            shouldRelock = false
            showLockScreen()
        }
    }

    private fun showLockScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundResource(com.elmosakes.whatsappreport.R.drawable.demon_background_overlay)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "حظر أرقام برعايه"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
        }
        root.addView(title, lp(-1, dp(58)))

        val subtitle = TextView(this).apply {
            text = "✦ أدخل كلمة السر للمتابعة ✦"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 104, 142))
        }
        root.addView(subtitle, lp(-1, dp(48)))

        val passwordField = EditText(this).apply {
            hint = "كلمة السر"
            textSize = 18f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(Color.rgb(175, 145, 160))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.rgb(36, 27, 34), Color.rgb(150, 55, 91), 14)
        }
        val fieldParams = lp(-1, dp(56)).apply { topMargin = dp(20) }
        root.addView(passwordField, fieldParams)

        val unlock = Button(this).apply {
            text = "دخول 🔓"
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(burgundy, Color.rgb(190, 68, 111), 16)
        }
        val buttonParams = lp(-1, dp(54)).apply { topMargin = dp(16) }
        root.addView(unlock, buttonParams)

        val error = TextView(this).apply {
            text = "كلمة السر غير صحيحة"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 120, 145))
            visibility = View.GONE
        }
        root.addView(error, lp(-1, dp(42)))

        unlock.setOnClickListener {
            if (passwordField.text.toString() == appPassword) {
                isUnlocked = true
                shouldRelock = false
                showMainScreen()
            } else {
                error.visibility = View.VISIBLE
                passwordField.text.clear()
                passwordField.requestFocus()
                Toast.makeText(this, "كلمة السر غير صحيحة", Toast.LENGTH_SHORT).show()
            }
        }

        passwordField.setOnEditorActionListener { _, _, _ ->
            unlock.performClick()
            true
        }
        setContentView(root)
    }

    private fun showMainScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            clipToPadding = false
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(240), dp(18), dp(22))
            setBackgroundResource(com.elmosakes.whatsappreport.R.drawable.demon_background_overlay)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)
        setContentView(scroll)

        // The artwork already contains the logo/title and demon character, so the form begins below it.
        val phoneCard = redCard()
        val phoneRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        phoneCard.addView(phoneRow, lp(-1, -2))
        val phoneIcon = TextView(this).apply {
            text = "☎"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 35, 66))
            background = rounded(Color.rgb(25, 4, 8), Color.rgb(255, 25, 54), 50)
        }
        phoneRow.addView(phoneIcon, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(12) })
        val phoneColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        phoneRow.addView(phoneColumn, LinearLayout.LayoutParams(0, -2, 1f))
        addLabel(phoneColumn, "رقم الهاتف أو واتساب")
        val phone = EditText(this).apply {
            hint = "+20 10 1234 5678"
            textSize = 17f
            setSingleLine(true)
            setTextColor(white)
            setHintTextColor(Color.rgb(145, 125, 151))
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(25, 19, 26), Color.rgb(125, 105, 133), 15)
        }
        phoneColumn.addView(phone, lp(-1, dp(52)))
        root.addView(phoneCard, lp(-1, -2).apply { bottomMargin = dp(12) })

        val reasonCard = redCard()
        reasonCard.setPadding(dp(14), dp(10), dp(14), dp(12))
        val reasonHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val reasonIcon = TextView(this).apply {
            text = "▤"
            textSize = 29f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 35, 66))
            background = rounded(Color.rgb(25, 4, 8), Color.rgb(255, 25, 54), 50)
        }
        reasonHeader.addView(reasonIcon, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(12) })
        val reasonTitle = TextView(this).apply {
            text = "سبب الإبلاغ"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        reasonHeader.addView(reasonTitle, LinearLayout.LayoutParams(0, dp(56), 1f))
        reasonCard.addView(reasonHeader, lp(-1, -2))

        val reason = EditText(this).apply {
            hint = "اكتب سبب البلاغ والتفاصيل هنا..."
            textSize = 16f
            minLines = 3
            gravity = Gravity.TOP or Gravity.RIGHT
            setTextColor(white)
            setHintTextColor(Color.rgb(145, 125, 151))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(25, 19, 26), Color.rgb(125, 105, 133), 15)
        }
        reasonCard.addView(reason, lp(-1, dp(106)).apply { topMargin = dp(8) })

        val choicesLabel = TextView(this).apply {
            text = "اختر سبب الإبلاغ (اختياري)"
            textSize = 14f
            setTextColor(white)
            gravity = Gravity.RIGHT
            setPadding(0, dp(14), 0, dp(8))
        }
        reasonCard.addView(choicesLabel, lp(-1, -2))

        val reasons = listOf(
            "محتوى غير لائق" to "⚠",
            "إزعاج متكرر" to "⊘",
            "انتحال شخصية" to "♟",
            "أسباب أخرى" to "☷",
            "تهديد أو عنف" to "☠",
            "احتيال" to "＄"
        )
        val selected = mutableSetOf<String>()
        val rows = listOf(reasons.take(3), reasons.drop(3))
        rows.forEach { rowItems ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            rowItems.forEach { (label, icon) ->
                val chip = TextView(this).apply {
                    text = "$label  $icon"
                    textSize = 12.5f
                    gravity = Gravity.CENTER
                    setTextColor(white)
                    setPadding(dp(5), dp(8), dp(5), dp(8))
                    background = rounded(Color.rgb(14, 5, 8), Color.rgb(255, 25, 54), 22)
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        if (selected.contains(label)) {
                            selected.remove(label)
                            background = rounded(Color.rgb(14, 5, 8), Color.rgb(255, 25, 54), 22)
                        } else {
                            selected.add(label)
                            background = rounded(Color.rgb(103, 7, 25), Color.rgb(255, 75, 96), 22)
                        }
                    }
                }
                row.addView(chip, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    leftMargin = dp(3); rightMargin = dp(3); bottomMargin = dp(6)
                })
            }
            reasonCard.addView(row, lp(-1, -2))
        }
        root.addView(reasonCard, lp(-1, -2).apply { bottomMargin = dp(14) })

        val send = Button(this).apply {
            text = "😈  ارفعو علي بتاعي  ➤"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(28, 2, 8), Color.rgb(110, 0, 22), Color.rgb(24, 2, 8))
            ).apply {
                cornerRadius = dp(34).toFloat()
                setStroke(dp(2), Color.rgb(255, 28, 57))
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(send, lp(-1, dp(76)).apply {
            leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(2)
        })

        send.setOnClickListener {
            val number = phone.text.toString().trim()
            val typedDetails = reason.text.toString().trim()
            val details = listOf(typedDetails, selected.joinToString("، ")).filter { it.isNotBlank() }.joinToString("\nأسباب مختارة: ")
            if (number.isBlank() || details.isBlank()) {
                Toast.makeText(this, "اكتب الرقم وسبب البلاغ أولًا", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val body = "أرغب في مراجعة الرقم التالي وفقًا لسياسات الخدمة:\nالرقم: $number\nسبب البلاغ: $details\n\nيرجى مراجعة البلاغ والتحقق منه. أرسل هذا البلاغ فقط إذا كانت المعلومات صحيحة."
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:support@whatsapp.com")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("support@whatsapp.com"))
                putExtra(Intent.EXTRA_SUBJECT, "طلب مراجعة بلاغ عن رقم واتساب")
                putExtra(Intent.EXTRA_TEXT, body)
            }
            try {
                startActivity(Intent.createChooser(intent, "اختر تطبيق البريد لمراجعة الرسالة"))
            } catch (_: Exception) {
                Toast.makeText(this, "لا يوجد تطبيق بريد متاح على الجهاز", Toast.LENGTH_LONG).show()
            }
        }

        val footer = TextView(this).apply {
            text = "✦  EL MOSAKES  ✦"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 40, 75))
            letterSpacing = 0.12f
        }
        root.addView(footer, lp(-1, dp(38)).apply { topMargin = dp(8) })
    }

    private fun redCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(218, 12, 3, 7), Color.argb(232, 18, 5, 10))
        ).apply {
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), Color.rgb(255, 30, 58))
        }
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun addLabel(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setPadding(0, dp(16), 0, dp(8))
        }
        parent.addView(label, lp(-1, -2))
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun lp(width: Int, height: Int) =
        LinearLayout.LayoutParams(width, height)

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
