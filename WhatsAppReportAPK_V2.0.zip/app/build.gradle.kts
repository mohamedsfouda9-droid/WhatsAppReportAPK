plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.elmosakes.whatsappreport"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.elmosakes.whatsappreport"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

    kotlinOptions {
        jvmTarget = "17"
    }
}

kotlin {
    jvmToolchain(17)
}
